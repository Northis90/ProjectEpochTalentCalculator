-- ============================================================
-- Epoch Talents v3.3
-- Better talent buttons + arrows + working scale
-- ============================================================

-- ============================================================
-- ACCOUNT-WIDE saved variable (see .toc SavedVariables)
-- File: WTF/Account/<Account>/SavedVariables/EpochTalents.lua
-- ============================================================
if type(_G.EpochTalentsDB) ~= "table" then
    _G.EpochTalentsDB = {}
end
EpochTalentsDB = _G.EpochTalentsDB
if type(EpochTalentsDB.builds) ~= "table" then
    EpochTalentsDB.builds = {}
end
-- builds["class_1"] = { ["1"] = {level=60, points=51, ranks={["124"]=3,...}}, ... }


local function GetBudget(level)
    if level < 10 or level > 60 then return 0 end
    local base = level - 9
    if level >= 14 then
        return base + math.min(10, math.floor((level - 14) / 5) + 1)
    end
    return base
end

local TREE_BACKGROUNDS = {
    [1]  = { "Interface\\TalentFrame\\WarriorArms-TopLeft", "Interface\\TalentFrame\\WarriorFury-TopLeft", "Interface\\TalentFrame\\WarriorProtection-TopLeft" },
    [2]  = { "Interface\\TalentFrame\\PaladinHoly-TopLeft", "Interface\\TalentFrame\\PaladinProtection-TopLeft", "Interface\\TalentFrame\\PaladinCombat-TopLeft" },
    [3]  = { "Interface\\TalentFrame\\HunterBeastMastery-TopLeft", "Interface\\TalentFrame\\HunterMarksmanship-TopLeft", "Interface\\TalentFrame\\HunterSurvival-TopLeft" },
    [4]  = { "Interface\\TalentFrame\\RogueAssassination-TopLeft", "Interface\\TalentFrame\\RogueCombat-TopLeft", "Interface\\TalentFrame\\RogueSubtlety-TopLeft" },
    [5]  = { "Interface\\TalentFrame\\PriestDiscipline-TopLeft", "Interface\\TalentFrame\\PriestHoly-TopLeft", "Interface\\TalentFrame\\PriestShadow-TopLeft" },
    [7]  = { "Interface\\TalentFrame\\ShamanElementalCombat-TopLeft", "Interface\\TalentFrame\\ShamanEnhancement-TopLeft", "Interface\\TalentFrame\\ShamanRestoration-TopLeft" },
    [8]  = { "Interface\\TalentFrame\\MageArcane-TopLeft", "Interface\\TalentFrame\\MageFire-TopLeft", "Interface\\TalentFrame\\MageFrost-TopLeft" },
    [9]  = { "Interface\\TalentFrame\\WarlockCurses-TopLeft", "Interface\\TalentFrame\\WarlockSummoning-TopLeft", "Interface\\TalentFrame\\WarlockDestruction-TopLeft" },
    [11] = { "Interface\\TalentFrame\\DruidBalance-TopLeft", "Interface\\TalentFrame\\DruidFeralCombat-TopLeft", "Interface\\TalentFrame\\DruidRestoration-TopLeft" },
}

local CLASS_ICON_TCOORDS = {
    [1]  = {0, 0.25, 0, 0.25},
    [2]  = {0, 0.25, 0.5, 0.75},
    [3]  = {0, 0.25, 0.25, 0.5},
    [4]  = {0.5, 0.75, 0, 0.25},
    [5]  = {0.5, 0.75, 0.25, 0.5},
    [7]  = {0.25, 0.5, 0.25, 0.5},
    [8]  = {0.25, 0.5, 0, 0.25},
    [9]  = {0.75, 1, 0.25, 0.5},
    [11] = {0.75, 1, 0, 0.25},
}
local CLASS_ICON_PATH = "Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes"

-- State
local currentClass = 1
local currentLevel = 60
local currentBuild = {}
local pointsSpent = 0
local talentButtons = {}
local arrowTextures = {}
local currentTab = "talents"
local uiScale = EpochTalentsDB.scale or 1.0

-- ===================== MAIN FRAME =====================
local frame = CreateFrame("Frame", "EpochTalentsFrame", UIParent)
frame:SetWidth(1020)
frame:SetHeight(700)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:SetFrameStrata("HIGH")
frame:SetScale(uiScale)
frame:Hide()

-- ESC closes the window
tinsert(UISpecialFrames, "EpochTalentsFrame")

-- Close when entering combat
local combatCloser = CreateFrame("Frame")
combatCloser:RegisterEvent("PLAYER_REGEN_DISABLED")
combatCloser:SetScript("OnEvent", function()
    if frame:IsShown() then
        frame:Hide()
    end
end)

local bg = frame:CreateTexture(nil, "BACKGROUND")
bg:SetPoint("TOPLEFT", 3, -3)
bg:SetPoint("BOTTOMRIGHT", -3, 3)
bg:SetTexture(0.07, 0.07, 0.09, 0.97)

frame:SetBackdrop({
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
frame:SetBackdropBorderColor(0.55, 0.55, 0.65, 1)

-- Top bar
local topBar = frame:CreateTexture(nil, "ARTWORK")
topBar:SetHeight(26)
topBar:SetPoint("TOPLEFT", 5, -5)
topBar:SetPoint("TOPRIGHT", -5, -5)
topBar:SetTexture(0.11, 0.11, 0.13, 1)

local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
title:SetPoint("TOP", 0, -11)
title:SetText("Talents")

local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", -2, -2)
close:SetWidth(26)
close:SetHeight(26)

-- Bottom bar
local bottomBar = frame:CreateTexture(nil, "ARTWORK")
bottomBar:SetHeight(24)
bottomBar:SetPoint("BOTTOMLEFT", 5, 5)
bottomBar:SetPoint("BOTTOMRIGHT", -5, 5)
bottomBar:SetTexture(0.11, 0.11, 0.13, 1)

local bottomLeftText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
bottomLeftText:SetPoint("LEFT", bottomBar, "LEFT", 10, 0)

local bottomRightText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
bottomRightText:SetPoint("RIGHT", bottomBar, "RIGHT", -10, 0)

-- Scale controls (instead of broken free resize)
local scaleLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
scaleLabel:SetPoint("BOTTOM", 0, 8)
scaleLabel:SetText("Scale")

local scaleDown = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
scaleDown:SetWidth(22)
scaleDown:SetHeight(18)
scaleDown:SetPoint("RIGHT", scaleLabel, "LEFT", -4, 0)
scaleDown:SetText("-")
scaleDown:SetScript("OnClick", function()
    uiScale = math.max(0.7, uiScale - 0.05)
    frame:SetScale(uiScale)
    EpochTalentsDB.scale = uiScale
end)

local scaleUp = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
scaleUp:SetWidth(22)
scaleUp:SetHeight(18)
scaleUp:SetPoint("LEFT", scaleLabel, "RIGHT", 4, 0)
scaleUp:SetText("+")
scaleUp:SetScript("OnClick", function()
    uiScale = math.min(1.4, uiScale + 0.05)
    frame:SetScale(uiScale)
    EpochTalentsDB.scale = uiScale
end)

-- Tabs
local tabTalents = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
tabTalents:SetWidth(75)
tabTalents:SetHeight(18)
tabTalents:SetPoint("TOPLEFT", 12, -36)
tabTalents:SetText("Talents")
tabTalents:SetScript("OnClick", function() currentTab = "talents" UpdateDisplay() end)

local tabGlyphs = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
tabGlyphs:SetWidth(75)
tabGlyphs:SetHeight(18)
tabGlyphs:SetPoint("LEFT", tabTalents, "RIGHT", 3, 0)
tabGlyphs:SetText("Glyphs")
tabGlyphs:SetScript("OnClick", function() currentTab = "glyphs" UpdateDisplay() end)

-- Class icon buttons
local classOrder = {1, 2, 3, 4, 5, 7, 8, 9, 11}
local classButtons = {}

for i, classID in ipairs(classOrder) do
    local btn = CreateFrame("Button", nil, frame)
    btn:SetWidth(32)
    btn:SetHeight(32)
    btn:SetPoint("TOPLEFT", 16 + (i-1)*42, -60)

    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    icon:SetTexture(CLASS_ICON_PATH)
    local tc = CLASS_ICON_TCOORDS[classID]
    if tc then icon:SetTexCoord(tc[1], tc[2], tc[3], tc[4]) end
    btn.icon = icon

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetBlendMode("ADD")
    border:SetPoint("CENTER")
    border:SetWidth(48)
    border:SetHeight(48)
    btn.border = border

    btn:SetScript("OnClick", function()
        currentClass = classID
        currentBuild = {}
        pointsSpent = 0
        currentTab = "talents"
        UpdateDisplay()
    end)
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(TalentDBClassNames[classID] or "?", 1, 1, 1)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", GameTooltip_Hide)

    classButtons[classID] = btn
end

local function UpdateClassButtons()
    for id, btn in pairs(classButtons) do
        if id == currentClass then
            btn.border:SetVertexColor(1, 0.82, 0.1)
            btn.icon:SetVertexColor(1, 1, 1)
        else
            btn.border:SetVertexColor(0.45, 0.45, 0.55)
            btn.icon:SetVertexColor(0.65, 0.65, 0.65)
        end
    end
end

-- Level
local levelLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
levelLabel:SetPoint("TOPLEFT", 14, -100)
levelLabel:SetText("Level:")

local levelEdit = CreateFrame("EditBox", nil, frame)
levelEdit:SetWidth(42)
levelEdit:SetHeight(18)
levelEdit:SetPoint("LEFT", levelLabel, "RIGHT", 4, 0)
levelEdit:SetAutoFocus(false)
levelEdit:SetMaxLetters(2)
levelEdit:SetNumeric(true)
levelEdit:SetFontObject(GameFontHighlight)
levelEdit:SetText("60")
levelEdit:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 10,
    insets = { left = 3, right = 3, top = 2, bottom = 2 }
})
levelEdit:SetBackdropColor(0.1, 0.1, 0.14, 1)
levelEdit:SetBackdropBorderColor(0.4, 0.4, 0.5, 1)
levelEdit:SetTextInsets(3, 3, 0, 0)

local function ApplyLevel()
    local num = tonumber(levelEdit:GetText())
    if not num then levelEdit:SetText(tostring(currentLevel)) return end
    num = math.max(10, math.min(60, num))
    if num ~= currentLevel then
        if pointsSpent > GetBudget(num) then currentBuild = {} pointsSpent = 0 end
        currentLevel = num
        UpdateDisplay()
    end
    levelEdit:SetText(tostring(currentLevel))
    levelEdit:ClearFocus()
end
levelEdit:SetScript("OnEnterPressed", ApplyLevel)
levelEdit:SetScript("OnEditFocusLost", ApplyLevel)
levelEdit:SetScript("OnEscapePressed", function(self) self:SetText(tostring(currentLevel)) self:ClearFocus() end)

local function ChangeLevel(d)
    local n = math.max(10, math.min(60, currentLevel + d))
    if n == currentLevel then return end
    if pointsSpent > GetBudget(n) then currentBuild = {} pointsSpent = 0 end
    currentLevel = n
    levelEdit:SetText(tostring(n))
    UpdateDisplay()
end

local upBtn = CreateFrame("Button", nil, frame)
upBtn:SetWidth(14)
upBtn:SetHeight(10)
upBtn:SetPoint("TOPLEFT", levelEdit, "TOPRIGHT", 1, 0)
upBtn:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up")
upBtn:SetScript("OnClick", function() ChangeLevel(1) end)

local downBtn = CreateFrame("Button", nil, frame)
downBtn:SetWidth(14)
downBtn:SetHeight(10)
downBtn:SetPoint("BOTTOMLEFT", levelEdit, "BOTTOMRIGHT", 1, 0)
downBtn:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
downBtn:SetScript("OnClick", function() ChangeLevel(-1) end)

levelEdit:EnableMouseWheel(true)
levelEdit:SetScript("OnMouseWheel", function(_, d) ChangeLevel(d) end)

-- Action buttons
local function MakeBtn(text, w, x)
    local b = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    b:SetWidth(w)
    b:SetHeight(18)
    b:SetPoint("TOPRIGHT", x, -100)
    b:SetText(text)
    return b
end

local function GetBuildString()
    local parts = {}
    for id, rank in pairs(currentBuild) do table.insert(parts, id .. ":" .. rank) end
    table.sort(parts)
    return string.format("ET;%d;%d;%s", currentClass, currentLevel, table.concat(parts, ","))
end

local function ApplyBuildString(str)
    local class, level, ranks = str:match("^ET;(%d+);(%d+);(.*)$")
    if not class then return false end
    currentClass = tonumber(class)
    currentLevel = tonumber(level)
    currentBuild = {}
    pointsSpent = 0
    if ranks and ranks ~= "" then
        for entry in ranks:gmatch("[^,]+") do
            local id, rank = entry:match("(%d+):(%d+)")
            if id and rank then
                currentBuild[tonumber(id)] = tonumber(rank)
                pointsSpent = pointsSpent + tonumber(rank)
            end
        end
    end
    levelEdit:SetText(tostring(currentLevel))
    UpdateDisplay()
    return true
end

-- ----- Reset with confirmation -----
local confirmFrame
local function ShowResetConfirm()
    if not confirmFrame then
        confirmFrame = CreateFrame("Frame", "EpochTalentsConfirm", UIParent)
        confirmFrame:SetWidth(320)
        confirmFrame:SetHeight(110)
        confirmFrame:SetPoint("CENTER")
        confirmFrame:SetFrameStrata("DIALOG")
        confirmFrame:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 8, right = 8, top = 8, bottom = 8 }
        })
        confirmFrame:EnableMouse(true)
        confirmFrame:SetMovable(true)
        confirmFrame:RegisterForDrag("LeftButton")
        confirmFrame:SetScript("OnDragStart", confirmFrame.StartMoving)
        confirmFrame:SetScript("OnDragStop", confirmFrame.StopMovingOrSizing)

        local t = confirmFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        t:SetPoint("TOP", 0, -18)
        t:SetWidth(280)
        t:SetJustifyH("CENTER")
        t:SetText("Reset all talent points on this build?")
        confirmFrame.text = t

        local yes = CreateFrame("Button", nil, confirmFrame, "UIPanelButtonTemplate")
        yes:SetWidth(90)
        yes:SetHeight(22)
        yes:SetPoint("BOTTOMLEFT", 30, 16)
        yes:SetText("Reset")
        yes:SetScript("OnClick", function()
            currentBuild = {}
            pointsSpent = 0
            UpdateDisplay()
            confirmFrame:Hide()
            print("|cff00ff00Epoch Talents:|r Build reset.")
        end)

        local no = CreateFrame("Button", nil, confirmFrame, "UIPanelButtonTemplate")
        no:SetWidth(90)
        no:SetHeight(22)
        no:SetPoint("BOTTOMRIGHT", -30, 16)
        no:SetText("Cancel")
        no:SetScript("OnClick", function() confirmFrame:Hide() end)
    end
    confirmFrame:Show()
end

local resetBtn = MakeBtn("Reset", 55, -10)
resetBtn:SetScript("OnClick", function()
    ShowResetConfirm()
end)

local exportBtn = MakeBtn("Export", 55, -70)
exportBtn:SetScript("OnClick", function()
    ShowImportExport("Export – copy this text", GetBuildString(), false)
end)

local linkBtn = MakeBtn("Link", 45, -130)
linkBtn:SetScript("OnClick", function()
    local str = GetBuildString()
    local name = TalentDBClassNames[currentClass] or "Talent"
    local msg = string.format("{EpochTalent:%s}", str)
    local link = string.format("|cff00ccff|Hepochtalent:%s|h[%s Talent Build]|h|r", str, name)

    local eb = ChatEdit_ChooseBoxForSend and ChatEdit_ChooseBoxForSend() or ChatFrame1EditBox
    if eb then
        if ChatFrame_OpenChat then
            ChatFrame_OpenChat(msg, DEFAULT_CHAT_FRAME)
        else
            ChatEdit_ActivateChat(eb)
            eb:SetText(msg)
            eb:SetFocus()
        end
    end
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Epoch Talents:|r Click to load this build: " .. link)
end)

local importBtn = MakeBtn("Import", 55, -180)
importBtn:SetScript("OnClick", function()
    ShowImportExport("Import – paste build string", "", true)
end)

-- Account-wide slots (shared by all characters)
-- Per-class account-wide slots: builds[classId][1..3]

-- ---------- Account-wide per-class save slots ----------
local function ClassKey(classId)
    return "class_" .. tostring(classId or 0)
end

local function SlotKey(slot)
    return tostring(slot)
end

local function GetClassBuildTable(classId)
    -- Always touch the global so SavedVariables sees changes
    if type(_G.EpochTalentsDB) ~= "table" then
        _G.EpochTalentsDB = {}
    end
    EpochTalentsDB = _G.EpochTalentsDB
    if type(EpochTalentsDB.builds) ~= "table" then
        EpochTalentsDB.builds = {}
    end
    local ck = ClassKey(classId)
    if type(EpochTalentsDB.builds[ck]) ~= "table" then
        EpochTalentsDB.builds[ck] = {}
    end
    return EpochTalentsDB.builds[ck]
end

local function RanksToSaved(build)
    -- Use string keys for ranks so SV serialization is reliable
    local out = {}
    for id, rank in pairs(build) do
        out[tostring(id)] = rank
    end
    return out
end

local function RanksFromSaved(saved)
    local out = {}
    if type(saved) ~= "table" then return out end
    for id, rank in pairs(saved) do
        local n = tonumber(id)
        if n and tonumber(rank) then
            out[n] = tonumber(rank)
        end
    end
    return out
end

local function GetSlotLabel(slot)
    local t = GetClassBuildTable(currentClass)
    local d = t[SlotKey(slot)]
    local className = TalentDBClassNames[currentClass] or ("Class " .. tostring(currentClass))
    if d and d.ranks then
        return string.format("%s Slot %d: Lv%s (%s pts)", className, slot, tostring(d.level or "?"), tostring(d.points or 0))
    end
    return string.format("%s Slot %d: (empty)", className, slot)
end

local function SaveToSlot(slot)
    local t = GetClassBuildTable(currentClass)
    local className = TalentDBClassNames[currentClass] or ("Class " .. tostring(currentClass))
    t[SlotKey(slot)] = {
        level = currentLevel,
        points = pointsSpent,
        ranks = RanksToSaved(currentBuild),
        name = className .. " Lv" .. tostring(currentLevel),
    }
    -- re-assign to force the global table to contain latest reference
    _G.EpochTalentsDB.builds[ClassKey(currentClass)] = t
    EpochTalentsDB = _G.EpochTalentsDB

    local count = 0
    for _ in pairs(currentBuild) do count = count + 1 end
    print(string.format("|cff00ff00Epoch Talents:|r SAVED %s -> slot %d (%d points, %d talents). Account-wide.",
        className, slot, pointsSpent, count))
end

local function LoadFromSlot(slot)
    local t = GetClassBuildTable(currentClass)
    local d = t[SlotKey(slot)]
    if not d or type(d.ranks) ~= "table" then
        print(string.format("|cffff5555Epoch Talents:|r %s slot %d is empty.",
            TalentDBClassNames[currentClass] or "Class", slot))
        return
    end
    currentLevel = tonumber(d.level) or currentLevel
    currentBuild = RanksFromSaved(d.ranks)
    pointsSpent = 0
    for _, rank in pairs(currentBuild) do
        pointsSpent = pointsSpent + rank
    end
    levelEdit:SetText(tostring(currentLevel))
    UpdateDisplay()
    print(string.format("|cff00ff00Epoch Talents:|r LOADED %s slot %d (%s).",
        TalentDBClassNames[currentClass] or "?", slot, d.name or "?"))
end


-- Save button opens a menu: Save 1 / Save 2 / Save 3
local saveBtn = MakeBtn("Save", 55, -240)
saveBtn:SetScript("OnClick", function(self)
    local menu = {
        { text = "Save to slot", isTitle = true, notCheckable = true },
        { text = GetSlotLabel(1), notCheckable = true, func = function() SaveToSlot(1) end },
        { text = GetSlotLabel(2), notCheckable = true, func = function() SaveToSlot(2) end },
        { text = GetSlotLabel(3), notCheckable = true, func = function() SaveToSlot(3) end },
        { text = "Cancel", notCheckable = true, func = function() end },
    }
    EasyMenu(menu, EpochTalentsMenuFrame or CreateFrame("Frame", "EpochTalentsMenuFrame", UIParent, "UIDropDownMenuTemplate"), "cursor", 0, 0, "MENU")
end)
saveBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Save build (account-wide)", 1, 1, 1)
    GameTooltip:AddLine("Click to choose slot 1, 2, or 3", 0.7, 0.7, 0.7)
    GameTooltip:Show()
end)
saveBtn:SetScript("OnLeave", GameTooltip_Hide)

-- Load button opens a menu: Load 1 / Load 2 / Load 3
local loadBtn = MakeBtn("Load", 55, -300)
loadBtn:SetScript("OnClick", function(self)
    local menu = {
        { text = "Load from slot", isTitle = true, notCheckable = true },
        { text = GetSlotLabel(1), notCheckable = true, func = function() LoadFromSlot(1) end },
        { text = GetSlotLabel(2), notCheckable = true, func = function() LoadFromSlot(2) end },
        { text = GetSlotLabel(3), notCheckable = true, func = function() LoadFromSlot(3) end },
        { text = "Cancel", notCheckable = true, func = function() end },
    }
    EasyMenu(menu, EpochTalentsMenuFrame or CreateFrame("Frame", "EpochTalentsMenuFrame", UIParent, "UIDropDownMenuTemplate"), "cursor", 0, 0, "MENU")
end)
loadBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Load build (account-wide)", 1, 1, 1)
    GameTooltip:AddLine("Click to choose slot 1, 2, or 3", 0.7, 0.7, 0.7)
    GameTooltip:Show()
end)
loadBtn:SetScript("OnLeave", GameTooltip_Hide)



-- Import/Export popup
local ieFrame
function ShowImportExport(titleText, text, isImport)
    if not ieFrame then
        ieFrame = CreateFrame("Frame", nil, UIParent)
        ieFrame:SetWidth(460)
        ieFrame:SetHeight(130)
        ieFrame:SetPoint("CENTER")
        ieFrame:SetFrameStrata("DIALOG")
        ieFrame:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 8, right = 8, top = 8, bottom = 8 }
        })
        ieFrame:EnableMouse(true)
        ieFrame:SetMovable(true)
        ieFrame:RegisterForDrag("LeftButton")
        ieFrame:SetScript("OnDragStart", ieFrame.StartMoving)
        ieFrame:SetScript("OnDragStop", ieFrame.StopMovingOrSizing)

        ieFrame.title = ieFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        ieFrame.title:SetPoint("TOP", 0, -12)

        ieFrame.edit = CreateFrame("EditBox", nil, ieFrame)
        ieFrame.edit:SetWidth(410)
        ieFrame.edit:SetHeight(26)
        ieFrame.edit:SetPoint("TOP", 0, -40)
        ieFrame.edit:SetAutoFocus(true)
        ieFrame.edit:SetFontObject(GameFontHighlight)
        ieFrame.edit:SetScript("OnEscapePressed", function() ieFrame:Hide() end)

        ieFrame.ok = CreateFrame("Button", nil, ieFrame, "UIPanelButtonTemplate")
        ieFrame.ok:SetWidth(80)
        ieFrame.ok:SetHeight(20)
        ieFrame.ok:SetPoint("BOTTOMLEFT", 30, 14)

        ieFrame.cancel = CreateFrame("Button", nil, ieFrame, "UIPanelButtonTemplate")
        ieFrame.cancel:SetWidth(80)
        ieFrame.cancel:SetHeight(20)
        ieFrame.cancel:SetPoint("BOTTOMRIGHT", -30, 14)
        ieFrame.cancel:SetText("Close")
        ieFrame.cancel:SetScript("OnClick", function() ieFrame:Hide() end)
    end

    ieFrame.title:SetText(titleText)
    ieFrame.edit:SetText(text or "")
    ieFrame.edit:HighlightText()
    ieFrame.edit:SetFocus()

    if isImport then
        ieFrame.ok:SetText("Import")
        ieFrame.ok:SetScript("OnClick", function()
            local raw = ieFrame.edit:GetText() or ""
            local payload = raw:match("{EpochTalent:(ET;[^}]+)}") or raw:match("(ET;%d+;%d+;[^%s]*)") or raw
            payload = strtrim(payload)
            if ApplyBuildString(payload) then
                ieFrame:Hide()
                frame:Show()
                print("|cff00ff00Epoch Talents:|r Build imported.")
            else
                print("|cffff5555Epoch Talents:|r Invalid build string.")
            end
        end)
    else
        ieFrame.ok:SetText("Select")
        ieFrame.ok:SetScript("OnClick", function()
            ieFrame.edit:HighlightText()
            ieFrame.edit:SetFocus()
        end)
    end
    ieFrame:Show()
end

-- Chat link support


-- ===================== CLICKABLE CHAT LINKS =====================
-- Send plain text so the server does not strip it.
-- On display, convert to a clickable hyperlink for anyone with the addon.

local function BuildClickableLink(payload)
    local classId = tonumber(payload:match("^ET;(%d+);"))
    local name = (classId and TalentDBClassNames[classId]) or "Talent"
    return string.format("|cff00ccff|Hepochtalent:%s|h[%s Talent Build]|h|r", payload, name)
end

local function ReplaceBuildCodes(msg)
    if type(msg) ~= "string" then return msg end
    -- {EpochTalent:ET;...}
    msg = msg:gsub("{EpochTalent:(ET;%d+;%d+;[^}]*)}", function(payload)
        return BuildClickableLink(payload)
    end)
    -- bare ET;class;level;ranks  (only if not already inside a link)
    if not msg:find("|Hepochtalent:") then
        msg = msg:gsub("(ET;%d+;%d+;[%d:,]+)", function(payload)
            return BuildClickableLink(payload)
        end)
    end
    return msg
end

local function ChatFilter(self, event, msg, author, ...)
    local newMsg = ReplaceBuildCodes(msg)
    if newMsg ~= msg then
        return false, newMsg, author, ...
    end
end

if ChatFrame_AddMessageEventFilter then
    local chatEvents = {
        "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
        "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
        "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
        "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM", "CHAT_MSG_CHANNEL",
    }
    for _, ev in ipairs(chatEvents) do
        ChatFrame_AddMessageEventFilter(ev, ChatFilter)
    end
end

-- Click handler
hooksecurefunc("SetItemRef", function(link, text, button)
    if type(link) == "string" and link:sub(1, 12) == "epochtalent:" then
        local payload = link:sub(13)
        if ApplyBuildString(payload) then
            frame:Show()
            print("|cff00ff00Epoch Talents:|r Build loaded from chat link.")
        else
            print("|cffff5555Epoch Talents:|r Could not read that build.")
        end
    end
end)


-- ===================== TREES =====================
local trees = {}

for t = 1, 3 do
    local tree = CreateFrame("Frame", nil, frame)
    tree:SetWidth(325)
    tree:SetHeight(520)
    tree:SetPoint("TOPLEFT", 12 + (t-1)*334, -125)

    local tbg = tree:CreateTexture(nil, "BACKGROUND")
    tbg:SetAllPoints()
    tbg:SetTexture("Interface\\TalentFrame\\HunterBeastMastery-TopLeft")
    tree.bg = tbg

    local overlay = tree:CreateTexture(nil, "BACKGROUND")
    overlay:SetAllPoints()
    overlay:SetTexture(0, 0, 0, 0.28)

    local border = CreateFrame("Frame", nil, tree)
    border:SetAllPoints()
    border:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 12,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    border:SetBackdropBorderColor(0.45, 0.45, 0.55, 0.9)

    local header = tree:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    header:SetPoint("TOP", 0, -7)
    tree.header = header

    local ptext = tree:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    ptext:SetPoint("TOP", header, "BOTTOM", 0, 0)
    tree.points = ptext

    tree.arrowLayer = CreateFrame("Frame", nil, tree)
    tree.arrowLayer:SetAllPoints()
    tree.buttonLayer = CreateFrame("Frame", nil, tree)
    tree.buttonLayer:SetAllPoints()

    trees[t] = tree
end

local glyphPanel = CreateFrame("Frame", nil, frame)
glyphPanel:SetPoint("TOPLEFT", 12, -125)
glyphPanel:SetPoint("BOTTOMRIGHT", -12, 34)
glyphPanel:Hide()
local glyphTitle = glyphPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
glyphTitle:SetPoint("TOP", 0, -30)
glyphTitle:SetText("Glyphs")
local glyphNote = glyphPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
glyphNote:SetPoint("TOP", glyphTitle, "BOTTOM", 0, -12)
glyphNote:SetWidth(500)
glyphNote:SetJustifyH("CENTER")
glyphNote:SetText("Glyph data is not available from the Project Epoch API yet.")

-- Helpers
local function PointsInPreviousTiers(treeIndex, row)
    local total = 0
    local list = TalentDB[currentClass] and TalentDB[currentClass][treeIndex]
    if not list then return 0 end
    for _, tal in ipairs(list) do
        if tal.row < row then total = total + (currentBuild[tal.id] or 0) end
    end
    return total
end

local function CanLearn(talent, treeIndex)
    local rank = currentBuild[talent.id] or 0
    if rank >= talent.maxRank then return false end
    if pointsSpent >= GetBudget(currentLevel) then return false end
    if PointsInPreviousTiers(treeIndex, talent.row) < (talent.row - 1) * 5 then return false end
    if talent.requires and (currentBuild[talent.requires.id] or 0) < talent.requires.rank then return false end
    return true
end

-- True if we are allowed to remove 1 point from this talent
local function CanUnlearn(talent, treeIndex)
    local rank = currentBuild[talent.id] or 0
    if rank <= 0 then return false end

    local list = TalentDB[currentClass] and TalentDB[currentClass][treeIndex]
    if not list then return true end

    -- Simulate removing one point
    local newRank = rank - 1

    -- 1) Nothing that requires THIS talent may still need a higher rank
    for _, other in ipairs(list) do
        if other.requires and other.requires.id == talent.id then
            local otherRank = currentBuild[other.id] or 0
            if otherRank > 0 and newRank < other.requires.rank then
                return false
            end
        end
    end

    -- 2) Tier gating: every talent that still has points must still satisfy
    --    "points in earlier rows >= (row-1)*5" after this point is removed
    --    Only points in THIS tree count for tier requirements.
    for _, other in ipairs(list) do
        local otherRank = currentBuild[other.id] or 0
        if otherRank > 0 then
            -- points this talent contributes after the hypothetical remove
            local contrib = 0
            if other.id == talent.id then
                contrib = newRank
            else
                contrib = otherRank
            end

            -- total points in rows strictly above "other"
            local above = 0
            for _, t2 in ipairs(list) do
                if t2.row < other.row then
                    if t2.id == talent.id then
                        above = above + newRank
                    else
                        above = above + (currentBuild[t2.id] or 0)
                    end
                end
            end
            local needed = (other.row - 1) * 5
            if above < needed then
                return false
            end
        end
    end

    return true
end

local function ClearArrows()
    for _, tex in ipairs(arrowTextures) do tex:Hide() end
end

-- Clean arrows that match the real talent frame (dark vertical line + arrow head)
local function DrawArrow(tree, parentBtn, childBtn)
    if not parentBtn or not childBtn then return end

    local pRow = parentBtn.talent.row
    local cRow = childBtn.talent.row
    local pCol = parentBtn.talent.col
    local cCol = childBtn.talent.col

    -- Only draw when parent is above the child
    if cRow <= pRow then return end

    -- Only handle same-column (straight vertical) for clean look
    -- Different column connections stay simple
    local px, py = parentBtn:GetCenter()
    local cx, cy = childBtn:GetCenter()
    if not px or not cx then return end

    local left = tree.arrowLayer:GetLeft()
    local bottom = tree.arrowLayer:GetBottom()
    if not left then return end

    px = px - left
    py = py - bottom
    cx = cx - left
    cy = cy - bottom

    if pCol == cCol then
        -- ===== Straight vertical arrow (most common) =====
        -- Thin dark vertical line
        local line = tree.arrowLayer:CreateTexture(nil, "ARTWORK")
        line:SetTexture("Interface\Buttons\WHITE8X8")
        line:SetVertexColor(0.15, 0.15, 0.18, 0.95)  -- near-black like the real frame
        line:SetWidth(3)
        local gap = 6
        local lineHeight = math.abs(py - cy) - 22
        if lineHeight < 4 then lineHeight = 4 end
        line:SetHeight(lineHeight)
        line:SetPoint("TOP", tree.arrowLayer, "BOTTOMLEFT", px, py - 16)
        line:Show()
        table.insert(arrowTextures, line)

        -- Arrow head (down pointing)
        local head = tree.arrowLayer:CreateTexture(nil, "ARTWORK")
        head:SetTexture("Interface\Buttons\UI-SortArrow")
        head:SetVertexColor(0.2, 0.2, 0.25, 1)
        head:SetWidth(12)
        head:SetHeight(12)
        head:SetPoint("BOTTOM", childBtn, "TOP", 0, 1)
        head:SetRotation(math.pi)  -- point downward
        head:Show()
        table.insert(arrowTextures, head)
    else
        -- ===== Simple bent / angled connection =====
        local line = tree.arrowLayer:CreateTexture(nil, "ARTWORK")
        line:SetTexture("Interface\Buttons\WHITE8X8")
        line:SetVertexColor(0.15, 0.15, 0.18, 0.9)
        line:SetWidth(3)
        local midY = (py + cy) / 2
        -- vertical part from parent down to mid
        local vlen = math.abs(py - midY) - 8
        if vlen > 2 then
            line:SetHeight(vlen)
            line:SetPoint("TOP", tree.arrowLayer, "BOTTOMLEFT", px, py - 14)
            line:Show()
            table.insert(arrowTextures, line)
        end

        -- horizontal connector
        local hline = tree.arrowLayer:CreateTexture(nil, "ARTWORK")
        hline:SetTexture("Interface\Buttons\WHITE8X8")
        hline:SetVertexColor(0.15, 0.15, 0.18, 0.9)
        hline:SetHeight(3)
        local hlen = math.abs(cx - px)
        hline:SetWidth(hlen)
        hline:SetPoint("LEFT", tree.arrowLayer, "BOTTOMLEFT", math.min(px, cx), midY)
        hline:Show()
        table.insert(arrowTextures, hline)

        -- vertical down to child
        local vline2 = tree.arrowLayer:CreateTexture(nil, "ARTWORK")
        vline2:SetTexture("Interface\Buttons\WHITE8X8")
        vline2:SetVertexColor(0.15, 0.15, 0.18, 0.9)
        vline2:SetWidth(3)
        local vlen2 = math.abs(midY - cy) - 10
        if vlen2 > 2 then
            vline2:SetHeight(vlen2)
            vline2:SetPoint("TOP", tree.arrowLayer, "BOTTOMLEFT", cx, midY)
            vline2:Show()
            table.insert(arrowTextures, vline2)
        end

        local head = tree.arrowLayer:CreateTexture(nil, "ARTWORK")
        head:SetTexture("Interface\Buttons\UI-SortArrow")
        head:SetVertexColor(0.2, 0.2, 0.25, 1)
        head:SetWidth(12)
        head:SetHeight(12)
        head:SetPoint("BOTTOM", childBtn, "TOP", 0, 1)
        head:SetRotation(math.pi)
        head:Show()
        table.insert(arrowTextures, head)
    end
end

local function UpdateButtonVisual(btn)
    local tal = btn.talent
    local rank = currentBuild[tal.id] or 0

    -- Always show rank/maxRank  e.g. 0/5, 2/3, 5/5
    btn.rankText:SetText(rank .. "/" .. tal.maxRank)
    btn.rankText:Show()

    -- Default: no glow (hidden). Glow only appears on mouseover.
    if not btn._hovering then
        btn.border:SetAlpha(0)
    end

    if rank >= tal.maxRank then
        btn.icon:SetVertexColor(1, 1, 1)
        btn.rankText:SetTextColor(1, 0.9, 0.2)
        btn._glowColor = {1, 0.82, 0.1}
    elseif rank > 0 then
        btn.icon:SetVertexColor(1, 1, 1)
        btn.rankText:SetTextColor(0.4, 0.9, 1)
        btn._glowColor = {0.3, 0.75, 1}
    else
        if CanLearn(tal, btn.treeIndex) then
            btn.icon:SetVertexColor(1, 1, 1)
            btn.rankText:SetTextColor(0.75, 0.75, 0.75)
            btn._glowColor = {0.4, 1, 0.4}
        else
            btn.icon:SetVertexColor(0.4, 0.4, 0.4)
            btn.rankText:SetTextColor(0.45, 0.45, 0.45)
            btn._glowColor = {0.5, 0.5, 0.5}
        end
    end
end

function UpdateDisplay()
    for _, btn in pairs(talentButtons) do
        btn:Hide()
        btn:SetParent(nil)
    end
    talentButtons = {}
    ClearArrows()
    UpdateClassButtons()

    if currentTab == "glyphs" then
        for t = 1, 3 do trees[t]:Hide() end
        glyphPanel:Show()
        title:SetText("Glyphs")
        bottomLeftText:SetText("")
        bottomRightText:SetText("")
        return
    end

    glyphPanel:Hide()
    for t = 1, 3 do trees[t]:Show() end

    local className = TalentDBClassNames[currentClass] or "Unknown"
    title:SetText(className .. " Talents")
    local budget = GetBudget(currentLevel)
    bottomRightText:SetText("Unspent Talents: " .. (budget - pointsSpent))
    levelEdit:SetText(tostring(currentLevel))

    local backgrounds = TREE_BACKGROUNDS[currentClass]
    local totalTreeText = {}

    for t = 1, 3 do
        local tree = trees[t]
        local list = TalentDB[currentClass] and TalentDB[currentClass][t]
        local specName = (TalentDBSpecNames[currentClass] and TalentDBSpecNames[currentClass][t]) or ("Tree " .. t)

        if backgrounds and backgrounds[t] then
            tree.bg:SetTexture(backgrounds[t])
        end

        tree.header:SetText(specName)

        local treePts = 0
        if list then
            for _, tal in ipairs(list) do
                treePts = treePts + (currentBuild[tal.id] or 0)
            end
        end
        tree.points:SetText(treePts .. " points")
        table.insert(totalTreeText, specName .. ": " .. treePts)

        if list then
            for _, tal in ipairs(list) do
                local btn = CreateFrame("Button", nil, tree.buttonLayer)
                btn:SetWidth(40)
                btn:SetHeight(40)

                -- Tighter grid like the real talent frame
                local x = 30 + (tal.col - 1) * 72
                local y = -44 - (tal.row - 1) * 52
                btn:SetPoint("TOPLEFT", x, y)

                -- Icon
                local icon = btn:CreateTexture(nil, "ARTWORK")
                icon:SetPoint("TOPLEFT", 3, -3)
                icon:SetPoint("BOTTOMRIGHT", -3, 3)
                icon:SetTexture("Interface\\Icons\\" .. (tal.icon or "INV_Misc_QuestionMark"))
                icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
                btn.icon = icon

                -- Dark square frame (always visible, like the real talent frame)
                local frameTex = btn:CreateTexture(nil, "BORDER")
                frameTex:SetTexture("Interface\\Buttons\\UI-Quickslot2")
                frameTex:SetPoint("CENTER")
                frameTex:SetWidth(52)
                frameTex:SetHeight(52)
                frameTex:SetVertexColor(0.7, 0.7, 0.75, 1)
                btn.frameTex = frameTex

                -- Glow border (hidden by default, shown only on mouseover)
                local border = btn:CreateTexture(nil, "OVERLAY")
                border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
                border:SetBlendMode("ADD")
                border:SetPoint("CENTER")
                border:SetWidth(58)
                border:SetHeight(58)
                border:SetAlpha(0)
                btn.border = border
                btn._hovering = false
                btn._glowColor = {1, 1, 1}

                -- Rank text: always 0/5 style, bottom-right
                local rankText = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                rankText:SetPoint("BOTTOMRIGHT", 2, 1)
                rankText:SetFont(GameFontHighlightSmall:GetFont(), 11, "OUTLINE")
                btn.rankText = rankText

                btn.talent = tal
                btn.treeIndex = t

                btn:SetScript("OnEnter", function(self)
                    -- show glow on mouseover
                    self._hovering = true
                    local c = self._glowColor or {1, 1, 1}
                    self.border:SetVertexColor(c[1], c[2], c[3], 1)
                    self.border:SetAlpha(0.95)

                    local tal = self.talent
                    local rank = currentBuild[tal.id] or 0
                    local specName = (TalentDBSpecNames[currentClass] and TalentDBSpecNames[currentClass][self.treeIndex]) or "this tree"
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:ClearLines()
                    GameTooltip:AddLine(tal.name, 1, 1, 1)
                    GameTooltip:AddLine("Rank " .. rank .. "/" .. tal.maxRank, 1, 0.82, 0)

                    if rank > 0 and tal.ranks and tal.ranks[rank] then
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine(tal.ranks[rank].description, 1, 0.82, 0, true)
                        if tal.ranks[rank].spellId and tal.ranks[rank].spellId > 0 then
                            GameTooltip:AddLine("SpellID: " .. tal.ranks[rank].spellId, 0.45, 0.45, 0.45)
                        end
                    end
                    if rank < tal.maxRank and tal.ranks and tal.ranks[rank + 1] then
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine("Next rank:", 0.35, 0.75, 1)
                        GameTooltip:AddLine(tal.ranks[rank + 1].description, 0.8, 0.8, 0.8, true)
                    end
                    if tal.requires then
                        local have = currentBuild[tal.requires.id] or 0
                        local col = have >= tal.requires.rank and "|cff00ff00" or "|cffff2020"
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine(col .. "Requires " .. tal.requires.rank .. " points in prerequisite|r")
                    end
                    local needed = (tal.row - 1) * 5
                    if needed > 0 then
                        local have = PointsInPreviousTiers(self.treeIndex, tal.row)
                        local col = have >= needed and "|cff00ff00" or "|cffff2020"
                        GameTooltip:AddLine(col .. "Requires " .. needed .. " points in " .. specName .. "|r")
                    end
                    GameTooltip:AddLine(" ")
                    if rank > 0 and not CanUnlearn(tal, self.treeIndex) then
                        GameTooltip:AddLine("|cffff5555Cannot unlearn: required by later talents|r")
                    end
                    GameTooltip:AddLine("|cff88ccffLeft-click: Learn   Right-click: Unlearn|r")
                    GameTooltip:Show()
                end)
                btn:SetScript("OnLeave", function(self)
                    self._hovering = false
                    self.border:SetAlpha(0)
                    GameTooltip:Hide()
                end)

                btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
                btn:SetScript("OnClick", function(self, button)
                    local tal = self.talent
                    local rank = currentBuild[tal.id] or 0
                    if button == "LeftButton" then
                        if CanLearn(tal, self.treeIndex) then
                            currentBuild[tal.id] = rank + 1
                            pointsSpent = pointsSpent + 1
                            UpdateDisplay()
                        end
                    elseif button == "RightButton" then
                        if rank > 0 and CanUnlearn(tal, self.treeIndex) then
                            currentBuild[tal.id] = (rank > 1) and (rank - 1) or nil
                            pointsSpent = pointsSpent - 1
                            UpdateDisplay()
                        end
                    end
                end)

                talentButtons[tal.id] = btn
                UpdateButtonVisual(btn)
                btn:Show()
            end

            for _, tal in ipairs(list) do
                if tal.requires then
                    local child = talentButtons[tal.id]
                    local parent = talentButtons[tal.requires.id]
                    if child and parent then
                        DrawArrow(tree, parent, child)
                    end
                end
            end
        end
    end

    bottomLeftText:SetText(table.concat(totalTreeText, "   "))
end

-- Minimap
local minimapBtn = CreateFrame("Button", "EpochTalentsMinimapButton", Minimap)
minimapBtn:SetWidth(32)
minimapBtn:SetHeight(32)
minimapBtn:SetFrameStrata("MEDIUM")
minimapBtn:SetPoint("TOPLEFT", Minimap, "TOPLEFT", 8, -8)
minimapBtn:SetMovable(true)
minimapBtn:EnableMouse(true)
minimapBtn:RegisterForClicks("LeftButtonUp")
minimapBtn:RegisterForDrag("LeftButton")
minimapBtn:SetScript("OnDragStart", minimapBtn.StartMoving)
minimapBtn:SetScript("OnDragStop", minimapBtn.StopMovingOrSizing)
minimapBtn:SetNormalTexture("Interface\\Icons\\Ability_Warrior_InnerRage")
minimapBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
minimapBtn:SetScript("OnClick", function()
    if frame:IsShown() then frame:Hide() else UpdateDisplay() frame:Show() end
end)
minimapBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Epoch Talents", 1, 1, 1)
    GameTooltip:AddLine("Left-click to toggle", 0.8, 0.8, 0.8)
    GameTooltip:Show()
end)
minimapBtn:SetScript("OnLeave", GameTooltip_Hide)

-- Slash
SLASH_EPOCHTALENTS1 = "/et"
SLASH_EPOCHTALENTS2 = "/epochtalents"
SlashCmdList["EPOCHTALENTS"] = function(msg)
    msg = strtrim(msg or "")
    local lower = msg:lower()
    if lower:find("^import") then
        local str = msg:match("[Ii]mport%s+(.+)") or ""
        -- accept both raw ET;... and {EpochTalent:ET;...}
        local payload = str:match("{EpochTalent:(ET;[^}]+)}") or str:match("(ET;%d+;%d+;.*)") or str
        payload = strtrim(payload)
        if payload ~= "" and ApplyBuildString(payload) then
            frame:Show()
            print("|cff00ff00Epoch Talents:|r Build imported.")
        else
            ShowImportExport("Import Build – paste the code here", str, true)
        end
    else
        if frame:IsShown() then frame:Hide() else UpdateDisplay() frame:Show() end
    end
end


-- ---------- SavedVariables load + logout flush ----------
local function CountSavedBuilds()
    local n = 0
    if type(EpochTalentsDB) == "table" and type(EpochTalentsDB.builds) == "table" then
        for _, classTable in pairs(EpochTalentsDB.builds) do
            if type(classTable) == "table" then
                for _, slotData in pairs(classTable) do
                    if type(slotData) == "table" and (slotData.ranks or slotData.build) then
                        n = n + 1
                    end
                end
            end
        end
    end
    return n
end

local svFrame = CreateFrame("Frame")
svFrame:RegisterEvent("ADDON_LOADED")
svFrame:RegisterEvent("PLAYER_LOGOUT")
svFrame:RegisterEvent("PLAYER_LEAVING_WORLD")
svFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == "EpochTalents" then
        if type(_G.EpochTalentsDB) ~= "table" then
            _G.EpochTalentsDB = {}
        end
        EpochTalentsDB = _G.EpochTalentsDB
        if type(EpochTalentsDB.builds) ~= "table" then
            EpochTalentsDB.builds = {}
        end

        -- Migrate very old flat format: builds[1].build
        local builds = EpochTalentsDB.builds
        if builds[1] and type(builds[1]) == "table" and builds[1].build and not builds["class_1"] then
            local old1, old2, old3 = builds[1], builds[2], builds[3]
            EpochTalentsDB.builds = {}
            for i, d in ipairs({ old1, old2, old3 }) do
                if d and d.build then
                    local cid = d.class or 1
                    local ck = "class_" .. tostring(cid)
                    EpochTalentsDB.builds[ck] = EpochTalentsDB.builds[ck] or {}
                    local ranks = {}
                    for id, rank in pairs(d.build) do
                        ranks[tostring(id)] = rank
                    end
                    EpochTalentsDB.builds[ck][tostring(i)] = {
                        level = d.level,
                        points = d.points,
                        ranks = ranks,
                        name = d.name,
                    }
                end
            end
            print("|cff00ff00Epoch Talents:|r Migrated old save format.")
        end

        -- Migrate previous per-class numeric format: builds[11][1]
        local toMigrate = {}
        for k, v in pairs(EpochTalentsDB.builds) do
            if type(k) == "number" and type(v) == "table" then
                toMigrate[k] = v
            end
        end
        for cid, slots in pairs(toMigrate) do
            local ck = "class_" .. tostring(cid)
            EpochTalentsDB.builds[ck] = EpochTalentsDB.builds[ck] or {}
            for slot, d in pairs(slots) do
                if type(d) == "table" then
                    local ranks = d.ranks
                    if not ranks and d.build then
                        ranks = {}
                        for id, rank in pairs(d.build) do
                            ranks[tostring(id)] = rank
                        end
                    end
                    if ranks then
                        EpochTalentsDB.builds[ck][tostring(slot)] = {
                            level = d.level,
                            points = d.points,
                            ranks = ranks,
                            name = d.name,
                        }
                    end
                end
            end
            EpochTalentsDB.builds[cid] = nil
        end

        if EpochTalentsDB.scale then
            uiScale = EpochTalentsDB.scale
            if frame then frame:SetScale(uiScale) end
        end

        print("|cff00ff00Epoch Talents:|r Account saves loaded (" .. CountSavedBuilds() .. " builds).")
    elseif event == "PLAYER_LOGOUT" or event == "PLAYER_LEAVING_WORLD" then
        -- Make sure global points at our table before client writes SavedVariables
        if type(EpochTalentsDB) == "table" then
            _G.EpochTalentsDB = EpochTalentsDB
        end
    end
end)

print("|cff00ff00Epoch Talents v3.3|r loaded. Type |cffffff00/et|r  |  Saves are account-wide")
